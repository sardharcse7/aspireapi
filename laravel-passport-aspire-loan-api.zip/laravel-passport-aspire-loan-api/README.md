# laravel-passport-auth

[Laravel 7|8 REST API with Passport Authentication Tutorial](https://www.positronx.io/laravel-rest-api-with-passport-authentication-tutorial/)